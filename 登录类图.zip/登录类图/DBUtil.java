/***********************************************************************
 * Module:  DBUtil.java
 * Author:  Administrator
 * Purpose: Defines the Class DBUtil
 ***********************************************************************/

import java.util.*;

/** @pdOid d0d5a207-556d-4ee3-869e-1bb316e2b2bf */
public class DBUtil {
   /** @pdOid 9dedb385-4d54-453b-b8e3-73803eb90e97 */
   public Connection getConnection() {
      // TODO: implement
      return null;
   }

}