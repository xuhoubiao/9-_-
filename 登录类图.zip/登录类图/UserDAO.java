/***********************************************************************
 * Module:  UserDAO.java
 * Author:  Administrator
 * Purpose: Defines the Class UserDAO
 ***********************************************************************/

import java.util.*;

/** @pdOid 853bebf6-c027-40dc-a429-6c5b067a46f7 */
public class UserDAO {
   /** @pdOid beb3238e-6ba0-4adf-8590-a506700d6673 */
   private DBUtil db;
   
   /** @pdRoleInfo migr=no name=DBUtil assc=association2 */
   public DBUtil dBUtil;
   
   /** @param userName 
    * @param userPassword
    * @pdOid aa8363d7-244c-47b7-ac2a-48662f285210 */
   public boolean findUser(String userName, String userPassword) {
      // TODO: implement
      return false;
   }

}