/***********************************************************************
 * Module:  MainClass.java
 * Author:  Administrator
 * Purpose: Defines the Class MainClass
 ***********************************************************************/

import java.util.*;

/** @pdOid 88aa5c62-d84c-4a56-bb1a-5b6552fb9a7b */
public class MainClass {
   /** @param args
    * @pdOid 255c3fdb-5c18-47f6-bb95-189f7e68b781 */
   public void main(String[] args) {
      // TODO: implement
   }

}