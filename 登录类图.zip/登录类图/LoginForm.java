/***********************************************************************
 * Module:  LoginForm.java
 * Author:  Administrator
 * Purpose: Defines the Class LoginForm
 ***********************************************************************/

import java.util.*;

/** @pdOid 4bc7570c-44ef-4be1-8187-1b07fbbc46e0 */
public class LoginForm {
   /** @pdOid e34daf1a-bba6-4e5f-980b-ab0b0d3f595e */
   private UserDAO dao;
   
   /** @pdRoleInfo migr=no name=UserDAO assc=association1 */
   public UserDAO userDAO;
   
   /** @pdOid 818ac837-7a68-4034-a213-9cdf1d40a714 */
   public void init() {
      // TODO: implement
   }
   
   /** @pdOid faf2ef06-1b8e-45de-a3b9-a8920fe272d9 */
   public void display() {
      // TODO: implement
   }
   
   /** @pdOid e12ade9f-ced0-41c4-869e-3510906a9afb */
   public void validate() {
      // TODO: implement
   }

}